/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frquizzserver;

/**
 *
 * @author alfonso
 */
public enum ServerState {
    LOGGED, NOT_LOGGED, LISTENING_ANSWER, CORRECT_ANSWER, WRONG_ANSWER, WIN, LOSE
}
