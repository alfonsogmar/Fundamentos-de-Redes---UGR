/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frquizzserver;

/**
 *
 * @author alfonso
 */
public enum QuestionCategory {
    HISTORY, GEOGRAFY, SPORTS, COMPUTER_NETWORKS, COMPUTER_SCIENCE
}
